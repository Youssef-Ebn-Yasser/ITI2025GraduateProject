# angular-live-compiler-bsncft6m

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/Ahmedyass7/angular-live-compiler-bsncft6m)