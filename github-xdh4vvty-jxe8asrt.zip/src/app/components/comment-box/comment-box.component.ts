import { Component } from '@angular/core';

@Component({
  selector: 'app-comment-box',
  imports: [],
  templateUrl: './comment-box.component.html',
  styleUrl: './comment-box.component.css'
})
export class CommentBoxComponent {

}
