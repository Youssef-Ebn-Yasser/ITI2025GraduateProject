export interface Icategory {
  id: number;
  name: String;
}
