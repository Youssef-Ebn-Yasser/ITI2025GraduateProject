import { Component, OnInit } from '@angular/core';
import { enSize, Iproduct } from '../../models/iproduct';
import { ProductService } from '../../services/product.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cart',
  imports: [FormsModule],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  enSize = enSize;
  cartIds: number[] = [];
  productsCart: Iproduct[] = [];
  productService: ProductService;

  subTotal: number = 0;
  discount: number = 0;
  deliveryFee: number = 0;
  total: number = 0;

  constructor(productService: ProductService) {
    this.productService = productService;
  }

  ngOnInit() {
    this.cartIds = JSON.parse(localStorage.getItem('cart') || '[]');

    for (let id of this.cartIds) {
      let product = this.productService.getProductById(id);

      if (product) {
        this.productsCart.push(product);
        this.subTotal += product.price;
      }
    }

    this.deliveryFee = this.subTotal * (this.discount / 100);
    this.total = this.subTotal - this.discount;
  }

  // ✅ دالة آمنة لتحويل enum enSize إلى string
  getSizeName(size: enSize): string {
    return enSize[size as unknown as keyof typeof enSize] as string;
  }

  applyDiscount(val: any) {
    const discountVal = Number(val);
    if (isNaN(discountVal) || discountVal < 0 || discountVal > 100) {
      alert("❌ Please enter a valid discount between 0 and 100");
      return;
    }
    this.discount = discountVal;
    this.deliveryFee = this.subTotal * (this.discount / 100);
    this.total = this.subTotal - this.deliveryFee;
  }

  minusProductCount(product: Iproduct) {
    if (product.payNumber <= 1) return;
    product.payNumber -= 1;
    this.subTotal -= product.price;
    this.total = this.subTotal - this.deliveryFee;
  }

  plusProductCount(product: Iproduct) {
    if (product.payNumber >= 10) {
      alert("Cannot add more than 10");
      return;
    }
    product.payNumber += 1;
    this.subTotal += product.price;
    this.total = this.subTotal - this.deliveryFee;
  }
}
