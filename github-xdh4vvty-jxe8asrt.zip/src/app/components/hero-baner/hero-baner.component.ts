import { Component } from '@angular/core';

@Component({
  selector: 'app-hero-baner',
  imports: [],
  templateUrl: './hero-baner.component.html',
  styleUrl: './hero-baner.component.css'
})
export class HeroBanerComponent {

}
